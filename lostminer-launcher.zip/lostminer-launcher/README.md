# LostMiner Launcher

Launcher para o LostMiner (Android) com tela inicial JOGAR / MODS e gerenciador de mods `.ls`.

## Como gerar o APK pelo GitHub
1. Crie o repositório **Lostminer launcher** e envie todos os arquivos desta pasta (incluindo a pasta `.github`).
2. Abra a aba **Actions** → **Build APK** → **Run workflow** (ou faça um push na branch main).
3. Quando terminar, abra a execução e baixe o artefato **LostMiner-Launcher-APK** (ZIP com o `.apk`).
4. Instale o `.apk` no celular (permita instalar de fontes desconhecidas).

## O que já funciona
- Tela inicial com JOGAR, MODS e contador (ligados / desligados / total).
- Importar `.ls` pelo seletor de arquivos; só aceita `.ls` e valida o conteúdo.
- Mensagens MOD IMPORTADO COM SUCESSO / ERRO AO IMPORTAR; mod com erro não é salvo.
- Lista de mods com LIGAR/DESLIGAR, APAGAR e status LIGADO/DESLIGADO.
- Estado salvo em disco (continua depois de fechar o app). Funciona offline.
- JOGAR copia só os mods ligados para `Android/data/com.lostminer.launcher/files/active_mods/` e abre o LostMiner (`com.fsilva.marcelo.lostminer`).

## Formato .ls (versão 1)
ZIP com `mod.json` na raiz:
```json
{ "name": "Meu Mod", "version": "1.0", "game": "lostminer", "ls_version": 1 }
```
Os outros arquivos do ZIP (ex.: imagens .png) fazem parte do mod. Há um exemplo em `exemplo/exemplo_mod.ls`.

## O que AINDA NÃO funciona (importante)
O LostMiner original não tem suporte a mods e não lê a pasta `active_mods`. O launcher prepara os mods
ligados e abre o jogo, mas **o jogo só aplicará os mods quando existir um carregador dentro dele**
(código do jogo ou APK modificado para ler `active_mods`). Esta parte depende do código-fonte do jogo.
Este projeto não foi compilado nem testado em aparelho antes de ser enviado.
