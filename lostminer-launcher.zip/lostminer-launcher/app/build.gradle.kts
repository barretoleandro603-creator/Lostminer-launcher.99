plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val gamePackage = "com.fsilva.marcelo.lostminer"

android {
    namespace = "com.lostminer.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lostminer.launcher"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        manifestPlaceholders["gamePackage"] = gamePackage
        buildConfigField("String", "GAME_PACKAGE", "\"$gamePackage\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
