package com.lostminer.launcher

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var big: TextView
    private lateinit var small: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(this)
        build()
    }

    override fun onResume() {
        super.onResume()
        Ui.immersive(this)
        refreshCounter()
    }

    private fun build() {
        val pad = Ui.dp(this, 20)
        val gap = Ui.dp(this, 14)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Ui.BG)
            setPadding(pad, pad, pad, pad)
        }

        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, pad, 0)
        }
        root.addView(left, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))

        left.addView(TextView(this).apply {
            text = "LOSTMINER"
            setTextColor(Ui.NEON)
            textSize = 30f
            typeface = Ui.mono
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = gap })

        left.addView(Ui.button(this, "▶  JOGAR", 28f) { play() },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = gap })

        left.addView(Ui.button(this, "MODS", 28f) {
            startActivity(Intent(this, ModsActivity::class.java))
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = gap })

        big = TextView(this).apply {
            setTextColor(Ui.TEXT)
            textSize = 20f
            typeface = Ui.mono
            gravity = Gravity.CENTER
        }
        small = TextView(this).apply {
            setTextColor(Ui.NEON)
            textSize = 13f
            typeface = Ui.mono
            gravity = Gravity.CENTER
        }
        left.addView(big, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        left.addView(small, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val art = ImageView(this).apply {
            setImageResource(R.drawable.arte)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = Ui.neonBg(this@MainActivity, Ui.PANEL, Ui.NEON_DIM)
            val p = Ui.dp(this@MainActivity, 8)
            setPadding(p, p, p, p)
        }
        root.addView(art, LinearLayout.LayoutParams(0, MATCH_PARENT, 1.3f))

        setContentView(root)
    }

    private fun refreshCounter() {
        val (total, on, off) = ModStore(this).counts()
        big.text = if (on == 1) "1 MOD LIGADO" else "$on MODS LIGADOS"
        small.text = "TOTAL: $total  ·  DESLIGADOS: $off"
    }

    private fun play() {
        val n = try {
            ModStore(this).prepareActive()
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao preparar os mods", Toast.LENGTH_LONG).show()
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(BuildConfig.GAME_PACKAGE)
        if (intent == null) {
            Toast.makeText(this, "LostMiner não está instalado", Toast.LENGTH_LONG).show()
            return
        }
        val msg = if (n == 0) "Iniciando sem mods" else "$n mod(s) preparado(s)"
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        startActivity(intent)
    }
}
