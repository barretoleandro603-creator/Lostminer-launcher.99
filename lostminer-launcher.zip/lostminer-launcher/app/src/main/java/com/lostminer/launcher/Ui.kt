package com.lostminer.launcher

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.TextView

object Ui {
    val BG = 0xFF0B0714.toInt()
    val PANEL = 0xFF140C22.toInt()
    val NEON = 0xFF9B30FF.toInt()
    val NEON_DIM = 0xFF4B2A7A.toInt()
    val TEXT = 0xFFF2EAFF.toInt()
    val GREEN = 0xFF55FF7F.toInt()
    val RED = 0xFFFF5577.toInt()
    val mono: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun neonBg(ctx: Context, fill: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(ctx, 6).toFloat()
            setColor(fill)
            setStroke(dp(ctx, 3), stroke)
        }

    @Suppress("DEPRECATION")
    fun immersive(a: Activity) {
        a.window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    fun button(ctx: Context, text: String, size: Float, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            this.text = text
            setTextColor(TEXT)
            textSize = size
            typeface = mono
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 18), dp(ctx, 12), dp(ctx, 18), dp(ctx, 12))
            background = neonBg(ctx, PANEL, NEON)
            isClickable = true
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.alpha = 0.6f
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
                }
                false
            }
            setOnClickListener { onClick() }
        }
}
